package example;

public class StackFullException extends RuntimeException {
    public StackFullException() {
    }
}
