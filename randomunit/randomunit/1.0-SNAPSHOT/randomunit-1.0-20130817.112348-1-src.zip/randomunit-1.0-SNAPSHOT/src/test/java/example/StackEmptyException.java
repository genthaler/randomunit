package example;

public class StackEmptyException extends RuntimeException {
    public StackEmptyException() {
    }
}
